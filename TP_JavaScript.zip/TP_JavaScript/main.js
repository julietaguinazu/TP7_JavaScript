
//variables se declaran con let, var,const
/*contador y contador global, son diferentes el segundo a plica a todo el programa
 */
//------------------INTRODUCCION A JAVASCRIPT-------------------
//EJERCICIO 2
let a=5;
let b=10;
let c=a+b;
// Imprimir el resultado en la consola
console.log("La suma de a y b es: " + c);

//EJERCICIO 3
// Le pido al usuario que ingrese su nombre usando prompt
let nombre = prompt("¿Cuál es tu nombre?");

// Imprimo un saludo con su nombre en cconsola
console.log("¡Hola, " + nombre + "!");

//----------------------OPERADORES LOGICOS----------------------
//EJERCICIO 1
let a1=5;
let b1=10;
let c1=15;

let n;
if (a > b) {
    
    if (a1 > c1) {
      n=a1;
    } else {
      n=c1;
    }
  } else{
    if (b1 > c1) {
        n=b1;
      } else {
        n=c1;
      }
  }
  console.log("El mayor de los tres numeros es  " + n + ".");

   //EJERCICIO 2
   
let numero = parseInt(prompt("Ingrese un número:"));


if (numero % 2 === 0) {
  console.log("El número " + numero + " es par.");
} else {
  console.log("El número " + numero + " es impar.");
}

//----------------------OPERADORES DE ASIGNACION Y BUCLES----------------------

//EJERCICIO 1 
let numero1 = 10;

while (numero1 >= 0) {
  console.log(numero1);
  numero1--;
}

//EJERCICIO 2
let numero2;

do {
  numero2 = parseInt(prompt("Ingresa un número mayor a 100:"));
} while (numero2 <= 100);

console.log("Ingresaste un número mayor a 100: " + numero2);

//----------------------FUNCIONES DE JAVASCRIPT----------------------

//EJERCICIO 1

function esPar(numero) {
    return numero % 2 === 0;
  }
  let numero3 = parseInt(prompt("Ingrese un número para saber si es par o no:"));
  
  console.log("El número " +numero3+ " es par: " + esPar(numero3));

//EJERCICIO 2

function convertirCelsiusAFahrenheit(celsius) {
    let fahrenheit = celsius * 1.8 + 32;
    return fahrenheit;
  }
  
  let gradosCelsius = parseInt(prompt("Ingrese los grados celcius:"));
  console.log(gradosCelsius + "°C son equivalentes a " + convertirCelsiusAFahrenheit(gradosCelsius)+ "°F");

//----------------------OBJETOS EN JAVASCRIPT----------------------

//EJERCICIO 1
const persona = {
    nombre: 'Julieta',
    edad: 22,
    ciudad: 'Mendoza',
    
    cambiarCiudad(nuevaCiudad) {
      this.ciudad = nuevaCiudad;
    }
  };
  console.log('Persona:', persona.nombre, ', Edad:', persona.edad, ', Ciudad:', persona.ciudad);
  persona.cambiarCiudad('Barcelona');
  console.log('Persona con ciudad actualizada:', persona.nombre, ', Edad:', persona.edad, ', Ciudad:', persona.ciudad);

  //EJERCICIO 2
  
  const libro = {
    titulo: 'El Quijote',
    autor: 'Miguel de Cervantes',
    anio: 1700,
    esAntiguo() {
      const anioActual = new Date().getFullYear();
      return anioActual - this.anio > 10;
    }
  };
  console.log(`El libro "${libro.titulo}" es antiguo: ${libro.esAntiguo()}`)

  //----------------------ARRAYS----------------------

//EJERCICIO 1

const numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const numerosMultiplicados = [];

for (let i = 0; i < numeros.length; i++) {
  numerosMultiplicados.push(numeros[i] * 2);
}

console.log("Números originales:", numeros);
console.log("Números multiplicados por 2:", numerosMultiplicados);

//EJERCICIO 2
let pares = [];

for (let i = 1; i <= 20; i++) {
  if (i % 2 === 0) {
    pares.push(i);
  }
}
console.log("Primeros 10 números pares:", pares);

